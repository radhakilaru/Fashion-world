-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Apr 29, 2017 at 06:12 PM
-- Server version: 5.7.17-log
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fashion world`
--

-- --------------------------------------------------------

--
-- Table structure for table `login_info`
--

CREATE TABLE `login_info` (
  `id` int(11) NOT NULL,
  `username` varchar(200) COLLATE latin1_bin NOT NULL,
  `password` varchar(200) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `login_info`
--

INSERT INTO `login_info` (`id`, `username`, `password`) VALUES
(1, 'Radha', 'd41d8cd98f00b204e9800998ecf8427e'),
(2, 'RK', 'aee92f16efd522b9326c25cc3237ac15'),
(3, 'LUCKY', 'b0df2270be9cb16c14537e5bc2f2d37b'),
(4, 'Hk rao', 'a029cadb3126cd224a8e80c7bb696e57'),
(5, 'Naren', 'aee92f16efd522b9326c25cc3237ac15');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(200) COLLATE latin1_bin NOT NULL,
  `price` decimal(2,0) NOT NULL,
  `url` varchar(250) COLLATE latin1_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `url`) VALUES
(1, 'women', 58, '2.jpg'),
(2, 'men', 32, '1.jpg'),
(3, 'Gent Footwear', 69, '4.jpg'),
(4, 'Kids watch', 18, '11.jpg'),
(5, 'womens Footwear', 84, '5.jpg'),
(6, 'Mens watch', 56, '10.jpg'),
(8, 'womens watch', 36, '12.jpg'),
(9, 'Women Ethenic saree', 50, '6.jpg'),
(10, 'Women Lehanga', 40, '7.jpg'),
(11, 'Men suite', 50, '8.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `user_info`
--

CREATE TABLE `user_info` (
  `fname` varchar(200) COLLATE latin1_bin NOT NULL,
  `lname` varchar(200) COLLATE latin1_bin NOT NULL,
  `username` varchar(50) COLLATE latin1_bin NOT NULL,
  `password` varchar(50) COLLATE latin1_bin NOT NULL,
  `gender` varchar(150) COLLATE latin1_bin NOT NULL,
  `address` varchar(200) COLLATE latin1_bin NOT NULL,
  `city` varchar(200) COLLATE latin1_bin NOT NULL,
  `state` varchar(200) COLLATE latin1_bin NOT NULL,
  `country` varchar(200) COLLATE latin1_bin NOT NULL,
  `Zipcode` int(200) NOT NULL,
  `email` varchar(200) COLLATE latin1_bin NOT NULL,
  `mobile` bigint(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_bin;

--
-- Dumping data for table `user_info`
--

INSERT INTO `user_info` (`fname`, `lname`, `username`, `password`, `gender`, `address`, `city`, `state`, `country`, `Zipcode`, `email`, `mobile`) VALUES
('Hanumantha Rao', 'kilaru', 'Hk rao', 'a029cadb3126cd224a8e80c7bb696e57', 'M', '2-59 Kammavaripalem,Andhrapradesh', 'DL', 'AR', 'DZ', 521185, 'rkilaru9679@muleriders.saumag.edu', 4087593661),
('Lakshmi', 'kilaru', 'LUCKY', 'b0df2270be9cb16c14537e5bc2f2d37b', 'F', '2-59 kammavarpalem', 'MA', 'AR', 'AD', 71753, 'radha123536@gmail.com', 9912185591),
('Naresh', 'kilaru', 'Naren', 'aee92f16efd522b9326c25cc3237ac15', 'M', 'Elicott sity', 'Bld', 'MD', 'US', 52338, 'iamnaresh.kilaru@gmail.com', 4087593661),
('Radha', 'Kilaru', 'RK', 'aee92f16efd522b9326c25cc3237ac15', 'F', '2212 lacari street', 'MA', 'AR', 'AD', 71753, 'iamradha.kilaru@gmal.com', 9553602559),
('radha', 'kilaru', 'Radha', 'd41d8cd98f00b204e9800998ecf8427e', 'F', '2212 lacari Street', 'MA', 'AR', 'AD', 71753, 'radhakilaru05@gmail.com', 9726532218);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login_info`
--
ALTER TABLE `login_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_info`
--
ALTER TABLE `user_info`
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `login_info`
--
ALTER TABLE `login_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
