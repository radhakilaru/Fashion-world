<?php 
	session_start();
?> 
<?php
    error_reporting(0);
    $error = "";    
    if($_POST['register'] == "Register"){

    $connection=mysqli_connect("localhost","root","2093","Fashion World");
    if(!$connection){
      die("Error in connecting to the mysql");
    }

      $fname=trim($_POST['fname']);
      $fname=htmlspecialchars($fname);
      $fname=mysqli_real_escape_string($connection,$fname);
      if(empty($fname)){
        $error .= "Missing the First name</br>";
      }
      $lname=trim($_POST['lname']);
      $lname=htmlspecialchars($lname);
      $lname=mysqli_real_escape_string($connection,$lname);
      if(empty($lname)){
        $error .= "Missing the LastName</br>";
      }

      $username=trim($_POST['username']);
      $username=htmlspecialchars($username);
      $username=mysqli_real_escape_string($connection,$username);
      if(empty($username)){
        $error .= "Missing the username</br>";
      }

      $password=trim($_POST['password']);
      $password=htmlspecialchars($password);
      $password=mysqli_real_escape_string($connection,$password);
      $password=md5($password);
      if(empty($password)){
        $error .= "Missing the password</br>";
      }

      $gender=trim($_POST['gender']);
      $gender=htmlspecialchars($gender);
      $gender=mysqli_real_escape_string($connection,$gender);
      if(empty($gender)){
        $error .= "Ur missing the gender</br>";
      }
      $address=trim($_POST['address']);
      $address=htmlspecialchars($address);
      $address=mysqli_real_escape_string($connection,$address);
      if(empty($address)){
        $error .= "Ur missing the address</br>";
      }
      $city=trim($_POST['city']);
      $city=htmlspecialchars($city);
      $city=mysqli_real_escape_string($connection,$city);
      if(empty($city)){
        $error .= "Ur missing the City</br>";
      }

      $state=trim($_POST['state']);
      $state=htmlspecialchars($state);
      $state=mysqli_real_escape_string($connection,$state);
      if(empty($state)){
        $error .= "Ur missing the State</br>";
      }
      $country=trim($_POST['country']);
      $country=htmlspecialchars($country);
      $country=mysqli_real_escape_string($connection,$country);
      if(empty($country)){
        $error .= "Ur missing the qualification</br>";
      }
      $zipcode=trim($_POST['zipcode']);
      $zipcode=htmlspecialchars($zipcode);
      $zipcode=mysqli_real_escape_string($connection,$zipcode);
      if(empty($zipcode)){
        $error .= "Ur missing the Zipcode</br>";
      } 
        $email=trim($_POST['email']);
      $email=htmlspecialchars($email);
      $email=mysqli_real_escape_string($connection,$email);
      if(empty($email)){
        $error .= "Ur missing the Email</br>";
      }

         $mobile=trim($_POST['mobile']);
      $mobile=htmlspecialchars($mobile);
      $mobile=mysqli_real_escape_string($connection,$mobile);
      if(empty($mobile)){
        $error .= "Ur missing the Phone Number</br>";
      }


    if(empty($error)){
      $result=mysqli_query($connection, "SELECT `username` FROM `user_info` WHERE `username` LIKE '$username'");
      if(mysqli_num_rows($result)==1){
        while($row=mysqli_fetch_array($result)){
          if(($row[0] == $username)) {
            $error .= '<li>The '.$username.' is already exist!!!</li>';
          }
        }
      }else{
        $sql="INSERT INTO  `user_info` (
`fname` ,
`lname` ,
`username` ,
`password` ,
`gender` ,
`address` ,
`city` ,
`state` ,
`country` ,
`zipcode` ,
`email` ,
`mobile`
)
VALUES (
'$fname',  '$lname',  '$username',  '$password',  '$gender',  '$address',  '$city',  '$state',  '$country',  '$zipcode',  '$email', '$mobile')";
        if(!mysqli_query($connection,$sql)) {
          die('Error: ' . mysqli_error($connection));
        }else{
        $sql="INSERT INTO login_info (username, password) VALUES ('$username', '$password')";
          if (!mysqli_query($connection,$sql)) {
              die('Error: ' . mysqli_error($connection));
          }
          $_SESSION["message"] = "Registered Successfully!!!";
          header("Location: index.php");
          exit();
        }
        }
      mysqli_free_result($result);
      mysqli_close($connection);
    }
  }
?>
<html>
	<head>
		<title>Fashion World : Registration</title>
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/slider.css">
		<script src="jquery.js"></script>
		<style>
			.list{

				margin: 300px auto 100px auto;
			}

		</style>
	</head>
	<body>
		
		<div class="first">
			<div id="slideshow">
   <div>
     <img src="one.jpg">
   </div>
   <div>
     <img src="two.jpg">
   </div>
    <div>
     <img src="three.jpg">
   </div>
  
</div>
		</div>
		<div class="wrap">
			
			<div id="wrap">
					
					<div class="head">
				Fashion world
					</div>
					
					<div class="menu">
						<ul>
							<li><a href="index.php">Home</a></li>
              <!-- <li><a href="men.php">Men</a></li> -->
              <li><a href="products.php">Products</a></li>
							<!-- <li><a href="women.php">Women</a></li>  -->           
            <?php if( empty($_SESSION["username"]) ){ ?>
		    					<li class="active"><a href="registration.php">Registration</a></li>
								<li><a href="login.php">Login</a></li> 
  							<?php }else{?>
							<li><a href="logout.php">Logout</a></li>
  							<?php } ?> 
               <li><a href="cart.php">Cart (<?php error_reporting(0); echo count(json_decode($_COOKIE["cart"], true));?>)</a></li>
						</ul>
					</div>


			</div>
 <div id="wrap">
				
				
				<div class="imp">
					
					<form action="" method="post">
						
						<fieldset>
							<legend><h1>Registration</h1></legend>		
              <h1><?php echo $error;?></h1>
<table width="420px" align="center" style="border:2px solid #ffffff; border-radius:5px; width:450px; padding:10px; background-color:#aeb112; color:#fff;">

      <tr>     <td>First Name: </td> <td><input type="text" name="fname"  placeholder="First Name" maxlength="20" size="30" required> </td> </tr> 
           <tr> <td>Last Name:  </td> <td> <input type="text" name="lname" placeholder="Last Name" maxlength="20" size="30" required></td> </tr>
 
           <tr> <td>User Name: <td> <input type="text" name="username"placeholder="User Name" maxlength="20" size="30" required required></td> </tr>
 
           <tr> <td> Password: <td> <input type="password" name="password"></td> </tr>  
          <tr> <td> Gender:<br>
        
        <td> <input type="radio" value="F" name="gender">Female<br>
   
             <input type="radio" value="M" name="gender">Male<br>
            </td> </tr> 

       <tr> <td>Address:
<td><textarea  name="address" placeholder="Address" maxlength="1000" cols="32" rows="6"></textarea></td> </tr>
<tr> <td>City:
<td><select name="city" placeholder="City" maxlength="50"  required>
<option selected="" value="Default" required>(Please select a city)</option>
<option value="MA">Magnolia</option>
<option value="LR">little Rock</option>
<option value="DL">Dallas</option>
<option value="PL">Plano</option>
<option value="FR">Frisco</option>
    <option value="Bld">Baltimore</option>
</select></td> </tr>
<tr> <td>State:
<td><select name="state" placeholder="State" maxlength="50"  required>
<option selected="" value="Default" required>(Please select a State)</option>
<option value="AR">Arkansas</option>
<option value="TX">Texas</option>
<option value="FR">Florida</option>
<option value="NY">New York</option>
<option value="NJ">New Jersey</option>
<option value="MD">Mary land</option>
</select></td> </tr>
<tr> <td>Country:
<td><select name="country" placeholder="Country" maxlength="50"  required>
<option selected="" value="Default" required>(Please select a country)</option>
<option value="AF">Australia</option>
<option value="AL">Canada</option>
<option value="In">India</option>
<option value="AS">Russia</option>
<option value="US">USA</option>
</select></td> </tr>
<tr> <td>ZIP Code:<td>
<input type="text" name="zipcode" placeholder="Zip / Postal Code" maxlength="50" size="30" required  ></td> </tr>
<tr> <td>Email:<td>
<input type="text" name="email"   placeholder="Email Address" maxlength="50" size="30" required ></td> </tr>
<tr> <td>Mobile:<td>
<input type="text" name="mobile"  placeholder="Phone No" maxlength="50" size="30" required ></td> </tr>
<tr> <td><input type="submit" name="register" value="Register"></td></tr>
       </table>

						</fieldset>

					</form>

				</div>

					

			</div>	
				
				
			

				
 
    				 

			


			<footer>
			
			
				<div id="wrap">
					
					<div class="menu">
						<ul>
							
							<li><a href="tandc.html">Copyright &copy; 2017 by SAU Students</a></li>
							<li><a href="privacy_pol.html">Privacy Policy</a></li>
							
						</ul>
					</div>

				</div>


			

		</footer>

		</div>
		
<script src="slider.js"></script>
	</body>

</html>