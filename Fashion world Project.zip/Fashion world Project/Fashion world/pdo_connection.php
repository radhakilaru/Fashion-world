<?php 
  try {
      $connString = "mysql:host=localhost;dbname=Fashion world";
      $user = "root";
      $pass = "2093";
      $pdo = new PDO($connString,$user,$pass);
    }
  catch (PDOException $e) {
      die( $e->getMessage() );
  }
  class product{
    public $id;
    public $name;
    public $price;
    public $url;

    function __construct($record)
    {
      $this->id = $record['id'];
      $this->name = $record['name'];
      $this->price = $record['price'];
      $this->url = $record['url'];
    }
  }
  ?>
