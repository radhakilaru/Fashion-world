<!DOCTYPE html>

<html>
<head>
	<title>Account Page</title>
</head>

<body>
	<h1>Welcome to Account Page</h1>

	<a href="account.php">Account</a>

	<a href="Cart.php">Cart</a>

</body>
</html>