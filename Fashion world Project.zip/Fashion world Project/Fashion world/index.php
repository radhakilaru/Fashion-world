/* Radha Kilaru - 999993656*/
/* kishore vallapaneni-99999-3623*/
/*  Christine Pacheco, 9671-79094 */


<?php 
	session_start();
?>
<html>
	<head>
		<title>Fashion world</title>
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/slider.css">
		<script src="jquery.js"></script>
		<style>
			.list{

				margin: 300px auto 100px auto;
			}

		</style>
	</head>
	<body>
		
		<div class="first">
			<div id="slideshow">
   <div>
     <img src="one.jpg">
   </div>
   <div>
     <img src="img/index.jpg">
   </div>
    <div>
     <img src="three.jpg">
   </div>
  
</div>
		</div>
		<div class="wrap">
			
			<div id="wrap">
					
					<div class="head">
						Fashion world
					</div>
					
					<div class="menu">
						<ul>
							<li class="active"><a href="index.php">Home</a></li>
                            <!-- <li><a href="men.php">Men</a></li> -->
                            <li><a href="products.php">Products</a></li>
							<!-- <li><a href="women.php">Women</a></li> -->
						
					
                     
                            <?php if( empty($_SESSION["username"]) ){ ?>
		    					<li><a href="registration.php">Registration</a></li>
								<li><a href="login.php">Login</a></li> 
  							<?php }else{?>
							<li><a href="logout.php">Logout</a></li>
  							<?php } ?>
                           <li><a href="cart.php">Cart (<?php error_reporting(0); echo count(json_decode($_COOKIE["cart"], true));?>)</a></li>  
                                                          
						</ul>
					</div>


			</div>


			<div id="wrap">
				

				

					<div class="list">
						<center><h1 style="color: pink;"> 
						<?php echo $_SESSION["message"];$_SESSION["message"]=null;?>
						</h1></center>
				<div class="imgg">
					<a href="men.html">
					<img src="img/men.jpg" alt=""></a>
				</div>


						<ol>
							
							<li>
									
									<a href="menitem_pe_four.html">
										
										<img src="img/men/pe/4.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Casual Dark Grey
											</div>

											<div class="rate">
												Price:: 4.5$
											</div>

										</div>

									</a>

								</li>

							<li>
									
									<a href="menitem_polo_three.html">
										
										<img src="img/men/polos/3.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Green & Grey
											</div>

											<div class="rate">
												Price:: 5.5$
											</div>

										</div>

									</a>

								</li>
								<li>
									
									<a href="menitem_lp_five.html">
										
										<img src="img/men/lp/5.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Men Blue 
											</div>

											<div class="rate">
												Price:: 5$
											</div>

										</div>

									</a>

								</li>

						</ol>

						<div class="imgg">
					<a href="women.html">
					<img src="img/womenag.jpg" alt=""></a>
				</div>
							
						<ol>
							
							<li>
									
									<a href="womenitem_tops_four.html">
										
										<img src="img/women/tops/4.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Peach Toned
											</div>

											<div class="rate">
												Price:: 6.6$
											</div>

										</div>

									</a>

								</li>

								<li>
									
									<a href="womenitem_tshirts_one.html">
										
										<img src="img/women/tshirts/1.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Light Grey
											</div>

											<div class="rate">
												Price:: 2.9$
											</div>

										</div>

									</a>

								</li>
								<li>
									
									<a href="womenitem_tops_three.html">
										
										<img src="img/women/tops/3.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												White
											</div>

											<div class="rate">
												Price:: 3.5$
											</div>

										</div>

									</a>

								</li>

						</ol>
						<div class="imgg">
					<a href="women.html">
					<img src="img/women.jpg" alt=""></a>
				</div>
						<ol>
							
							<li>
									
									<a href="footwear_fflipflops_three.html">
										
										<img src="img/footwear/fflipflops/3.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Women Brown
											</div>

											<div class="rate">
												Price:: 2.6$
											</div>

										</div>

									</a>

								</li>
								<li>
									
									<a href="footwear_shoes_two.html">
										
										<img src="img/footwear/shoes/2.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Black Running
											</div>

											<div class="rate">
												Price:: 8$
											</div>

										</div>

									</a>

								</li>
								<li>
									
									<a href="footwear_flipflops_three.html">
										
										<img src="img/footwear/flipflops/3.jpg" alt="">

										<div class="txt">
											
											<div class="name">
												Grey_Red
											</div>

											<div class="rate">
												Price:: 2.1$
											</div>

										</div>

									</a>

								</li>

						</ol>
						<div class="imgg">
					<a href="men.html">
					<img src="img/menag.jpg" alt=""></a>
				</div>
					</div>

			</div>


			<footer>
			
			
				<div id="wrap">
					
					<div class="menu">
						<ul>
							
							<li><a href="tandc.html">Copyright &copy; 2017 by SAU Students</a></li>
							<li><a href="privacy_pol.html">Privacy Policy</a></li>
							
						</ul>
					</div>

				</div>


			

		</footer>

		</div>
		
<script src="slider.js"></script>
	</body>

</html>