<?php   
	session_start();
	setcookie("cart", "", time()-3600);
	unset($_COOKIE["cart"]);
	$_SESSION["message"] = "Uncart Successfully";
	header("Location: products.php");
?>