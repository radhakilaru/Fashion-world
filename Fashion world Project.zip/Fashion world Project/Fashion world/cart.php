<?php 
	session_start();
?>
<?php
    if(isset($_POST['addtocart'])  && $_POST['addtocart'] == "Add")
    {
        if(isset($_COOKIE["cart"]))
        {
            $result = json_decode($_COOKIE["cart"], true);
            $result[$_POST['hid']]=$_POST['quantity'];
            setcookie("cart",json_encode($result),time()+60*30);
            $_SESSION["message"] = "Item added to cart successfully";
            header("Location: products.php");
        }
        else
        {
            $item_array=array($_POST['hid']=>$_POST['quantity']);
            setcookie("cart",json_encode($item_array),time()+60*30);
            $_SESSION["message"] = "Item added to cart successfully";
            header("Location: products.php");
        }
    }
?>
<html>
	<head>
		<title>Fashion world : Products</title>
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/slider.css">
		<script src="jquery.js"></script>
		<style>
			.list{

				margin: 300px auto 100px auto;
			}

		</style>
	</head>
<body>

			<div id="wrap">
					
					<div class="head">
						Fashion world
					</div>
					
					<div class="menu">
						<ul>
							<li class="active"><a href="index.php">Home</a></li>
                            <!-- <li><a href="men.php">Men</a></li> -->
                            <li><a href="products.php">Products</a></li>
							<!-- <li><a href="women.php">Women</a></li> -->
						
					
                     
                  <?php if( empty($_SESSION["username"]) ){ ?>
		    					<li><a href="registration.php">Registration</a></li>
								<li><a href="login.php">Login</a></li> 
  							<?php }else{?>
							<li><a href="logout.php">Logout</a></li>
  							<?php } ?>
                            
                 <li><a href="cart.php">Cart (<?php error_reporting(0); echo count($mycart = json_decode($_COOKIE["cart"], true));?>)</a></li>                    
						</ul>
					</div>
			</div>	
<section id="home">
      <div class="container">
        <div class="row"><br><br>
<?php 
if(isset($_COOKIE["cart"])){
?>
<div class="row" style="background-color: rgba(215, 231, 245, 0.56);">
<center>
<?php
  include 'pdo_connection.php';
  ?>
  <table border="5" style="border: 5px solid blue;width: 50%;height: 50%;">
<caption><h3 style="background-color: lightgreen;color: blue;float: left;">Your Cart : </h3><a style="background-color: yellow;color:red;float: right;" href="checkout.php">checkout</a></caption>
<tr style="width: 20%;background-color: rgb(138, 132, 229);">
  <th align="center">Product Name</th>
f  <th align="center">Quantity</th><th align="center">Price</th>
</tr>
<?php
  $cartTotal=0;
  foreach ($mycart as $key => $value) { 
  $sql = "SELECT * FROM product where id=".$key;
  $result = $pdo->query($sql);
 ?>
  <div class="row">
  <?php    while ($proData=$result->fetch()) {   $mydata=new product($proData);
    ?>
     <tr>
    <td align="center"><?php echo $mydata->name; ?></td>
    <td align="center"><?php echo $value; ?></td>
    <td align="center">$<span><?php echo ($value*$mydata->price); ?></span></td>
    <?php $cartTotal=$cartTotal+($value*$mydata->price); ?>
    </tr>
  </div>
  <?php } ?>
  <br>
   <?php } ?>
   <tr>
    <td align="right" style="padding-right: 12%" colspan="2">Total</td>
    <td align="center">$<span><?php echo $cartTotal; ?></span></td>
  </tr>
</table>
  <br>
</center>
<?php }else{?>
  <center><h1 style="color:red;" class="text-center">Cart is empty</h1></center>
<?php } ?>
</div>
      </div>
</section>

			<footer>
			
			
				<div id="wrap">
					
					<div class="menu">
						<ul>
							
							<li><a href="tandc.html">Copyright &copy; 2017 by SAU students</a></li>
							<li><a href="privacy_pol.html">Privacy Policy</a></li>
							
						</ul>
					</div>

				</div>


			

		</footer>

		</div>
		
<script src="slider.js"></script>
	</body>

</html>