<!DOCTYPE html>

<html>
    
<head>
        
<title>
            Registration Page!!!
        </title>
  
  </head>
   
 <body>
        
<h1>Please register for our site!!</h1>
 
       <div id="wrap">
				
				
				<div class="imp">
					
					<form action="">
						
						<fieldset>
							<legend><h1>Registration</h1></legend>		
<table width="420px" align="center" style="border:2px solid #ffffff; border-radius:5px; width:450px; padding:10px; background-color:#aeb112; color:#fff;">

      <tr>     <td>First Name: </td> <td><input type="text" name="fname"> </td> </tr> 
           <tr> <td>Last Name:  </td> <td> <input type="text" name="lname"></td> </tr>
 
           <tr> <td>User Name: <td> <input type="text" name="uname"></td> </tr>
 
           <tr> <td> Password: <td> <input type="password" name="pw"></td> </tr>  
          <tr> <td> Gender:<br>
        
        <td> <input type="radio" value="F" name="gender">Female<br>
   
             <input type="radio" value="M" name="gender">Male<br>
            </td> </tr>   
        <tr> <td> State:
            <select name="state">
    
           <option value="ar">AR</option>
          
     <option value="tx">TX</option>
               
<option value="la">LA</option>
            </select><td> </tr>
            <tr> <td><input type="submit" value="sign-up"></td> </tr>
       </table>

						</fieldset>

					</form>

				</div>

					

			</div>
			  
  </body>

</html>