<?php 
	session_start();
?>
<html>
	<head>
		<title>Fashion world : Products</title>
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/slider.css">
		<script src="jquery.js"></script>
		<style>
			.list{

				margin: 300px auto 100px auto;
			}

		</style>
	</head>
<body>

			<div id="wrap">
					
					<div class="head">
						Fashion world
					</div>
					
					<div class="menu">
						<ul>
							<li><a href="index.php">Home</a></li>
                            <!-- <li><a href="men.php">Men</a></li> -->
                            <li class="active"><a href="products.php">Products</a></li>
							<!-- <li><a href="women.php">Women</a></li>  -->                    
                            <?php if( empty($_SESSION["username"]) ){ ?>
		    					<li><a href="registration.php">Registration</a></li>
								<li><a href="login.php">Login</a></li> 
  							<?php }else{?>
							<li><a href="logout.php">Logout</a></li>
  							<?php } ?>
                         <li><a href="cart.php">Cart (<?php error_reporting(0); echo count(json_decode($_COOKIE["cart"], true));?>)</a></li>
						</ul>
					</div>
			</div>
			<br><br><br>
		<center><h1 style="color: green;">
		<?php error_reporting(0);echo $_SESSION["message"];$_SESSION["message"]=null;?>
		</h1></center>
<?php
  include 'pdo_connection.php';
  $sql = "SELECT * FROM product";
  $result = $pdo->query($sql);
 ?>
  <center><h1><caption>Products</caption></h1>
      <div class="container">
<?php   while ($rowData=$result->fetch()) {
        $row=new product($rowData);
      if(!empty($row->name)){ ?>
        <div class="row">
          <div class="col-lg-4" >
            <form action="cart.php" method="POST" style="border: 6px dotted blue;width: 50%;height: 50%;background-color: lightgreen">
                <div><h3><?php echo $row->name; ?> : $<?php echo $row->price; ?></h3></p>
                <center><span class="text-center"><img width="250px" height="250px" src="<?php echo $row->url; ?>"></span></center><br>
                <input type="text" name="quantity">
                <input type="hidden" name="hid" value="<?php echo $row->id; ?>">
                <input type="hidden" name="hname" value="<?php echo $row->name; ?>"></h4>
                <input type="submit" name='addtocart' value="Add">
                </div>
            </form>
          </div>
         <?php  } ?>
      <?php  } ?>
      </div><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>
  </center>
			<footer>
			
			
				<div id="wrap">
					
					<div class="menu">
						<ul>
							
							<li><a href="tandc.html">Copyright &copy; 2017 by SAU</a></li>
							<li><a href="privacy_pol.html">Privacy Policy</a></li>
							
						</ul>
					</div>

				</div>


			

		</footer>

		</div>
		
<script src="slider.js"></script>
	</body>

</html>