<?php session_start(); ?>
<?php
    error_reporting(0);
    $error = "";
    $email = $password ="";
    $data = "";
    if($_POST['login'] == "Login"){
    $connection=mysqli_connect("localhost","root","2093","Fashion world");
    if(!$connection){
      die("Error in connecting to the mysql");
    }
      $username=trim($_POST['username']);
      $username=htmlspecialchars($username);
      $username=mysqli_real_escape_string($connection,$username);
      if(empty($username)){
        $error .= "Ur missing the Email</br>";
      }
      $password=trim($_POST['password']);
      $password=htmlspecialchars($password);
      $password=mysqli_real_escape_string($connection,$password);
      $password=md5($password);
      if(empty($password)){
        $error .= "Ur missing the password</br>";
      }
      if(empty($error)){
        $sql="SELECT * FROM login_info WHERE username='$username'";
        $result=mysqli_query($connection,$sql);
        if($result===false){
          die("Couldn't query the database");
        }else{
          $error .= "<li style='color:blue;' class='active'>Please check your username again.</li>";
        }
        if(mysqli_num_rows($result)==1){
          $row = mysqli_fetch_assoc($result);
          if($row["password"]==$password){
            $_SESSION["message"] = "Login Successfully...";
            $_SESSION["username"]=$username;
            header("Location: index.php");
          }else{
            $error = "<li style='color:blue;' class='active'>Please check your password again.</li>";
          }
        }
      }
    }
?>

<html>
	<head>
		<title>Fashion world</title>
		<link rel="stylesheet" href="css/styles.css">
		<link rel="stylesheet" href="css/slider.css">
		<script src="jquery.js"></script>
		<style>
			.list{

				margin: 300px auto 100px auto;
			}

		</style>
	</head>
	<body>
		
		<div class="first">
			<div id="slideshow">
   <div>
     <img src="one.jpg">
   </div>
   <div>
     <img src="two.jpg">
   </div>
    <div>
     <img src="three.jpg">
   </div>
  
</div>
		</div>
		<div class="wrap">
			
			<div id="wrap">
					
					<div class="head">
						Fashion world
					</div>
					
					<div class="menu">
						<ul>
							<li><a href="index.php">Home</a></li>
                            <!-- <li><a href="men.php">Men</a></li> -->
                            <li><a href="products.php">products</a></li>
							<!-- <li><a href="women.php">Women</a></li> -->
						        
                            <?php if( empty($_SESSION["username"]) ){ ?>
		    					<li><a href="registration.php">Registration</a></li>
								<li class="active"><a href="login.php">Login</a></li> 
  							<?php }else{?>
							<li><a href="logout.php">Logout</a></li>
  							<?php } ?>
  							 <li><a href="cart.php">Cart (<?php error_reporting(0); echo count(json_decode($_COOKIE["cart"], true));?>)</a></li>
</li>

    
						</ul>
					</div>
			</div>
				<div id="wrap">
			
				
				
					
						<center><h1 style="color: red;"> <?php echo $_SESSION["message"];$_SESSION["message"]=null;?></h1></center>
						<legend><h1>Login</h1></legend>		
						<form action="" method="post" >

<table width="420px" align="center" style="border:5px solid #ffffff; border-radius:5px; width:450px; padding:10px; background-color:#aeb112; color:#fff;">
				<tr> <td>User Name:<input type="text" name="username" ></td>
</tr>
				<tr> <td>Password:<input type="password" name="password" >
                </td> </tr>
				
                        <tr> <td><input type="submit" name="login" value="Login" >
	
			<input type="reset" name="Reset" ></td></tr>
 </table></fieldset>	
		</form>
</div>

	

			


			<footer>
			
			
				<div id="wrap">
					
					<div class="menu">
						<ul>
							
							<li><a href="tandc.html">Copyright &copy; 2017 by SAU students</a></li>
							<li><a href="privacy_pol.html">Privacy Policy</a></li>
							
						</ul>
					</div>

				</div>


			

		</footer>

		</div>
		
<script src="slider.js"></script>
	</body>

</html>

<?php
	function redirect($file)
	
   {
		$host=$_SERVER["HTTP_HOST"];
	
	$path=rtrim(dirname($_SERVER["PHP_SELF"]),"/\\");

		header("Location:http://$host$path/$file");
	}

?>