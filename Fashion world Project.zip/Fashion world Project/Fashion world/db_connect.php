<?
	$connection=mysqli_connect("localhost","root","2093");

	if(!$connection)
	{
		
       die("Error in connecting to the mysql");
	
    }

?>                 